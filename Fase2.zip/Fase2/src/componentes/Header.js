import React from 'react'
import imgastro from './imagens/img-astron-usuario.png'

export default function Header (props){

return(
    <>
     <header className='headerC'>
        <h1>{props.tituloCab}</h1>
        <div className='txt'>
            <a href='https://www.google.com.br/'>Usuario</a>
        </div>
        <div className='txt'>
            <a href='https://www.google.com.br/'>Comunidade</a>
        </div>
        <div className='txt'>
            <input type="text" name="search" placeholder="Pesquisar"/>
        </div>
        <div className='txt'>
            <a href='https://www.google.com.br/'>Duvidas</a>
        </div>
        <div className='txt'>
            <a href='https://www.google.com.br/'>Login</a>
        </div>
        <span><img className='img1' src={imgastro} alt="astronauta login"></img></span>
    </header>
    
    </>
   
)
}