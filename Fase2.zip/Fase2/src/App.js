import './App.css';
import Header from './componentes/Header'
import Footer from './componentes/Footer'
import figure from './componentes/imagens/14.png'

export default function App() {

  let tituloCab="Tec4All"
  let rede ="Siga a Tec4All nas nossas redes sociais."
  let link = "https://www.google.com.br/"
 
  return (
    <>
      <Header tituloCab={tituloCab}/>
      <div className='video'>
        <h1>O QUE É UM IPO?</h1>
      <p>Assinale a alternativa correta:</p>
      </div>
      <div className='form-title'>
        <form>
          <input type='radio' checked/>  É uma unidade económico-social, constituída por elementos humanos, materiais e técnicos, cujo objetivo é obter utilidades através da sua participação no mercado de bens e serviços. Nesse sentido, faz uso dos fatores produtivos (trabalho, terra e capital). <br/>
          <input type='radio' checked/> É é o conjunto de ativos que movimentam a economia e podem ser convertidos em dinheiro. <br/>
          <input type='radio' checked/> Todas as alternativas estão erradas <br/>
          <input type='radio' checked/> Oferta pública inicial é um tipo de oferta pública em que as ações de uma empresa são vendidas ao público em geral numa bolsa de valores pela primeira vez. É o processo pelo qual uma empresa se torna numa empresa de capital aberto. <br/>
        </form>
      </div>
      <div>
        <img className='img4' src={figure} alt="imagem"/>
      </div>
      <Footer rede={rede} link={link}/>
    </>
  );
}


