import React from 'react'
import redesocial from './imagens/img-astron-cel.png'

export default function Footer (props){


    return(
        <div className='footer' >
        
        <h2>{props.rede}</h2>
        <a href={props.link}>
            <img className='img2' src={redesocial} alt="rede social"/>
        </a>
        </div>
       

    )
}