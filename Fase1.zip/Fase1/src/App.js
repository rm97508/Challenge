import './App.css';
import Header from './componentes/Header'
import Footer from './componentes/Footer'

export default function App() {

  let tituloCab="Tec4All"
  let rede ="Siga a Tec4All nas nossas redes sociais."
  let link = "https://www.google.com.br/"
 
  return (
    <>
      <Header tituloCab={tituloCab}/>
      <div className='video'>
        <h1>O QUE É IPO?</h1>
        <p>Assista ao vídeo e entenda, assim poderá seguir para as proximas fases.</p>
        <object className='video'>   
          <iframe width="600" height="400" src="https://www.youtube.com/embed/KsvK-xIKb2c" title="IPO: o que é e como investir?" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </object>
      </div>
      <Footer rede={rede} link={link}/>
    </>
  );
}


