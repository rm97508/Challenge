import './App.css';
import Header from './componentes/Header'
import Footer from './componentes/Footer'
import Mundo1 from './componentes/imagens/8.png'
import Mundo2 from './componentes/imagens/6.png'
import Mundo3 from './componentes/imagens/13.png'


export default function App() {

  let tituloCab="Tec4All"
  let rede ="Siga a Tec4All nas nossas redes sociais."
  let link = "https://www.google.com.br/"
 


  return (
    <>
      <Header tituloCab={tituloCab}/>
      <div className='mundos'>
          <div className='box'>
            <span className='fases'>
                <a href='google.com' target="_blank">
                   <img className='efeito-flutuante-infinito' src={Mundo1} alt="planetas"/>
                  '<figcaption>Fase 1</figcaption>
                </a>
            </span>
          </div>
          <div className='box'>
            <span className='fases'>
                <a href='google.com' target="_blank">
                  <img className='efeito-flutuante-infinito' src={Mundo2} alt="planetas"/>
                  <figcaption>Fase 2</figcaption>
                </a>
            </span>
          </div>
        <div className='box'>
              <span className='fases'>
                <a href='google.com' target="_blank">
                  <img className='efeito-flutuante-infinito' src={Mundo3} alt="planetas"/>
                  <figcaption>Fase 3</figcaption>
                </a>
        </span>
        </div>
      </div>
      <Footer rede={rede} link={link}/>
    </>
  );
}


