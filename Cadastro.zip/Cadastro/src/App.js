import imgastro from './imagens/astronauta-pc.png'
import './style.css'

function App() {
  return (
   <div className="container">
      <div className="container-login">
        <div className="wrap-login">
          <form className="login-form">
            <h1 className='txt'>Cadastro</h1>
            <span className="login-form-title">Venha conosco nessa jornada!<br/>Veja como aprender IPO pode ser divertido.</span>
            <span className="login-form-title"> <img className='efeito-flutuante-infinito' src={imgastro} alt="astronauta login"/>
            </span>

            <div className='wrap-input'>
                <input className='input' type='text'/>
                <span className='focus-input' data-placeholder='Nome completo:'></span>
            </div>

            <div className='wrap-input'>
                <input className='input' type='number'/>
                <span className='focus-input' data-placeholder='Número do seu celular:'></span>
            </div>

            <div className='wrap-input'>
                <input className='input' type='email'/>
                <span className='focus-input' data-placeholder='E-mail:'></span>
            </div>

            <div className='wrap-input'>
                <input className='input' type='email'/>
                <span className='focus-input' data-placeholder='Repetir E-mail:'></span>
            </div>

            <div className='wrap-input'>
                <input className='input' type='password'/>
                <span className='focus-input' data-placeholder='Senha:'></span>
            </div>
            <div className='wrap-input'>
                <input className='input' type='password'/>
                <span className='focus-input' data-placeholder='Repetir senha:'></span>
            </div>

            <div className='container-login-form-btn'>
              <button className='login-form-btn'>Enviar</button>
            </div>

          </form>
        </div>
      </div>
   </div>
  );
}

export default App;
